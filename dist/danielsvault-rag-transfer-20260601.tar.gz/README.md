# DanielsVault RAG Transfer Bundle

Start here on the target machine:

```bash
tar -xzf danielsvault-rag-transfer-20260601.tar.gz
cd danielsvault-rag
./scripts/install-target.sh
```

Then set the vault location if it differs from Daniel's current Mac path:

```bash
export DANIELSVAULT_ROOT="/path/to/DanielsVault"
export PATH="$PWD/.venv/bin:$PATH"
rag runtime health
rag runtime smoke
```

Full setup, refresh, QMD, and Codex-skill notes are in:

```text
danielsvault-rag/DEPLOYMENT.md
```

Security note: this archive includes the current `.rag/store`, including private-scope indexed chunks. Treat it like sensitive vault data.

