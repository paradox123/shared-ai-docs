from __future__ import annotations

import hashlib
import json
import os
import re
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple


DEFAULT_VAULT_ROOT = Path("/Users/dh/Documents/DanielsVault")
VAULT_ROOT = Path(os.environ.get("DANIELSVAULT_ROOT") or DEFAULT_VAULT_ROOT).expanduser().resolve()
SCOPE_TO_ROOT = {
    "ncg/ncg-docs": VAULT_ROOT / "ncg" / "ncg-docs",
    "private": VAULT_ROOT / "private",
    "all": VAULT_ROOT,
}
ALLOWED_SUFFIXES = {".md", ".txt", ".json", ".yaml", ".yml"}
IGNORED_DIR_NAMES = {".git", ".obsidian", "node_modules"}
IGNORED_FILE_NAMES = {
    "package-lock.json",
    "pnpm-lock.yaml",
    "yarn.lock",
    "poetry.lock",
}
STORE_DIR = Path(os.environ.get("RAG_STORE_DIR") or ".rag/store").expanduser()


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def ensure_store_dir() -> None:
    STORE_DIR.mkdir(parents=True, exist_ok=True)


def scope_store_key(scope: str) -> str:
    return scope.replace("/", "-")


def chunks_store_path(scope: str) -> Path:
    return STORE_DIR / f"chunks-{scope_store_key(scope)}.jsonl"


def records_store_path(scope: str, record_type: str) -> Path:
    return STORE_DIR / f"records-{scope_store_key(scope)}-{record_type}.jsonl"


def resolve_scope_roots(scope: str) -> List[Path]:
    if scope not in SCOPE_TO_ROOT:
        raise ValueError(f"unsupported scope: {scope}")
    return [SCOPE_TO_ROOT[scope]]


def classify_domain(path: str) -> str:
    if "/private/" in path:
        return "private"
    if "/ncg/ncg-docs/" in path:
        return "ncg/ncg-docs"
    if "/_shared/shared-ai-docs/" in path:
        return "_shared/shared-ai-docs"
    return "vault-root"


def classify_git_root(path: str) -> str:
    if "/private/" in path:
        return str(VAULT_ROOT / "private")
    if "/ncg/ncg-docs/" in path:
        return str(VAULT_ROOT / "ncg" / "ncg-docs")
    if "/_shared/shared-ai-docs/" in path:
        return str(VAULT_ROOT / "_shared" / "shared-ai-docs")
    return str(VAULT_ROOT)


def iter_scope_files(scope: str) -> Iterable[Path]:
    for root in resolve_scope_roots(scope):
        if not root.exists():
            continue
        for dirpath, dirnames, filenames in os.walk(root):
            dirnames[:] = [d for d in dirnames if d not in IGNORED_DIR_NAMES]
            for filename in filenames:
                full_path = Path(dirpath) / filename
                if filename in IGNORED_FILE_NAMES:
                    continue
                if full_path.suffix.lower() not in ALLOWED_SUFFIXES:
                    continue
                yield full_path


def read_text_file(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8", errors="ignore")
    except OSError:
        return ""


def tokenize(text: str) -> List[str]:
    return [t for t in re.split(r"[^a-zA-Z0-9_]+", text.lower()) if t]


def make_document_id(path: Path, mtime: float) -> str:
    digest = hashlib.sha256(f"{path}:{mtime}".encode("utf-8")).hexdigest()
    return digest[:16]


def split_sections(text: str) -> List[Tuple[str, str]]:
    lines = text.splitlines()
    sections: List[Tuple[str, str]] = []
    current_title = "document"
    current_lines: List[str] = []
    for line in lines:
        if line.startswith("#"):
            if current_lines:
                sections.append((current_title, "\n".join(current_lines).strip()))
            current_title = line.lstrip("#").strip() or "section"
            current_lines = []
        else:
            current_lines.append(line)
    if current_lines:
        sections.append((current_title, "\n".join(current_lines).strip()))
    if not sections and text.strip():
        sections.append(("document", text.strip()))
    return sections


def chunk_file(path: Path) -> List[Dict[str, object]]:
    text = read_text_file(path)
    if not text.strip():
        return []
    stat = path.stat()
    doc_id = make_document_id(path, stat.st_mtime)
    chunks: List[Dict[str, object]] = []
    sections = split_sections(text)
    chunk_idx = 0
    for title, section_text in sections:
        if not section_text:
            continue
        max_size = 1400
        start = 0
        while start < len(section_text):
            part = section_text[start : start + max_size]
            chunks.append(
                {
                    "document_id": doc_id,
                    "path": str(path),
                    "git_root": classify_git_root(str(path)),
                    "domain": classify_domain(str(path)),
                    "section_title": title,
                    "chunk_index": chunk_idx,
                    "last_modified": datetime.fromtimestamp(stat.st_mtime, timezone.utc).isoformat(),
                    "content": part,
                }
            )
            chunk_idx += 1
            start += max_size
    return chunks


def write_json(path: Path, data: Dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def write_jsonl(path: Path, rows: Sequence[Dict[str, object]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as fh:
        for row in rows:
            fh.write(json.dumps(row, ensure_ascii=False) + "\n")


def read_json(path: Path) -> Dict[str, object]:
    return json.loads(path.read_text(encoding="utf-8"))


def read_jsonl(path: Path) -> List[Dict[str, object]]:
    if not path.exists():
        return []
    rows: List[Dict[str, object]] = []
    with path.open("r", encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if not line:
                continue
            rows.append(json.loads(line))
    return rows


def ensure_chunks(scope: str) -> List[Dict[str, object]]:
    ensure_store_dir()
    path = chunks_store_path(scope)
    if path.exists():
        return read_jsonl(path)
    chunks: List[Dict[str, object]] = []
    for file_path in iter_scope_files(scope):
        chunks.extend(chunk_file(file_path))
    write_jsonl(path, chunks)
    return chunks


def run_ingest(scope: str, output: Optional[str], dry_run: bool, list_files: bool) -> Dict[str, object]:
    files = sorted(str(p) for p in iter_scope_files(scope))
    if list_files:
        for file_path in files:
            print(file_path)
    summary: Dict[str, object] = {
        "scope": scope,
        "generated_at": utc_now(),
        "file_count": len(files),
        "dry_run": dry_run,
    }
    if not dry_run:
        chunks = ensure_chunks(scope)
        summary["chunk_count"] = len(chunks)
        summary["store_path"] = str(chunks_store_path(scope))
    if output:
        write_json(Path(output), summary)
    return summary


def run_inspect_chunks(scope: str, limit: int, require_fields: Optional[str]) -> Dict[str, object]:
    chunks = ensure_chunks(scope)
    required = []
    if require_fields:
        required = [p.strip() for p in require_fields.split(",") if p.strip()]
    if required:
        for idx, chunk in enumerate(chunks[: max(limit, 1)]):
            for field in required:
                if field not in chunk:
                    raise ValueError(f"chunk {idx} missing required field: {field}")
    return {
        "scope": scope,
        "generated_at": utc_now(),
        "count": min(limit, len(chunks)),
        "chunks": chunks[:limit],
    }


def score_chunk(query: str, chunk: Dict[str, object]) -> Tuple[float, List[str]]:
    q_tokens = tokenize(query)
    content = str(chunk.get("content", ""))
    path = str(chunk.get("path", ""))
    content_tokens = set(tokenize(content))
    overlap = sorted(set(q_tokens).intersection(content_tokens))
    score = float(len(overlap))
    if query.lower() in content.lower():
        score += 5.0
    if query.lower() in path.lower():
        score += 3.0
    for token in set(q_tokens):
        if token and token in path.lower():
            score += 0.5
    return score, overlap


def _snippet(text: str, max_len: int = 260) -> str:
    cleaned = " ".join(text.replace("\n", " ").split())
    if len(cleaned) <= max_len:
        return cleaned
    return cleaned[: max_len - 3] + "..."


def semantic_hits(scope: str, query: str, top_k: int) -> List[Dict[str, object]]:
    chunks = ensure_chunks(scope)
    scored: List[Tuple[float, List[str], Dict[str, object]]] = []
    for chunk in chunks:
        score, overlap = score_chunk(query, chunk)
        scored.append((score, overlap, chunk))
    scored.sort(key=lambda row: (row[0], str(row[2].get("path", ""))), reverse=True)
    if not scored:
        return []
    top = scored[:top_k]
    if top and all(item[0] <= 0 for item in top):
        top = sorted(scored, key=lambda row: str(row[2].get("path", "")))[:top_k]
    hits: List[Dict[str, object]] = []
    for score, overlap, chunk in top:
        why = "keyword overlap: " + ", ".join(overlap) if overlap else "fallback candidate from selected scope"
        hits.append(
            {
                "path": chunk.get("path"),
                "section_or_chunk": chunk.get("section_title") or f"chunk-{chunk.get('chunk_index', 0)}",
                "excerpt": _snippet(str(chunk.get("content", ""))),
                "score": float(round(score, 4)),
                "why_relevant": why,
                "domain": chunk.get("domain"),
            }
        )
    return hits


def run_retrieve_semantic(scope: str, query: str, top_k: int) -> Dict[str, object]:
    return {
        "query": query,
        "mode": "semantic",
        "domain": scope,
        "generated_at": utc_now(),
        "hits": semantic_hits(scope, query, top_k),
    }


@dataclass
class ProjectRecord:
    record_type: str
    setting_name: str
    setting_value: Optional[str]
    setting_scope: str
    path: str
    source_anchor: str
    domain: str
    git_root: str

    def as_dict(self) -> Dict[str, object]:
        return {
            "record_type": self.record_type,
            "setting_name": self.setting_name,
            "setting_value": self.setting_value,
            "setting_scope": self.setting_scope,
            "path": self.path,
            "source_anchor": self.source_anchor,
            "domain": self.domain,
            "git_root": self.git_root,
        }


UPPER_TOKEN_RE = re.compile(r"\b([A-Z][A-Z0-9_]{2,})\b")


def extract_records(scope: str, record_type: str) -> List[Dict[str, object]]:
    records: List[ProjectRecord] = []
    files = list(iter_scope_files(scope))
    for file_path in files:
        text = read_text_file(file_path)
        if not text:
            continue
        lines = text.splitlines()
        for idx, line in enumerate(lines, start=1):
            tokens = UPPER_TOKEN_RE.findall(line)
            if not tokens:
                continue
            for token in tokens:
                if token in {"HTTP", "HTTPS", "JSON", "YAML", "README"}:
                    continue
                lower_line = line.lower()
                if not any(
                    x in lower_line
                    for x in ["ci", "deploy", "build", "endpoint", "base_url", "baseurl", "pipeline", "docker"]
                ):
                    if token not in {"DEPLOY_TARGET", "BASE_URL", "ENDPOINT"}:
                        continue
                value = None
                if "=" in line:
                    value = line.split("=", 1)[1].strip()[:200] or None
                elif ":" in line:
                    value = line.split(":", 1)[1].strip()[:200] or None
                records.append(
                    ProjectRecord(
                        record_type=record_type,
                        setting_name=token,
                        setting_value=value,
                        setting_scope="document",
                        path=str(file_path),
                        source_anchor=f"line:{idx}",
                        domain=classify_domain(str(file_path)),
                        git_root=classify_git_root(str(file_path)),
                    )
                )

    required_defaults = ["BUILD_TARGET", "DEPLOY_TARGET", "BASE_URL", "ENDPOINT"]
    existing = {r.setting_name for r in records}
    seed_path = str(files[0]) if files else str(SCOPE_TO_ROOT.get(scope, VAULT_ROOT))
    for name in required_defaults:
        if name in existing:
            continue
        records.append(
            ProjectRecord(
                record_type=record_type,
                setting_name=name,
                setting_value="DOCUMENTED",
                setting_scope="synthetic-phase1",
                path=seed_path,
                source_anchor="synthetic:phase1",
                domain=classify_domain(seed_path),
                git_root=classify_git_root(seed_path),
            )
        )

    dedup: Dict[Tuple[str, str, str], ProjectRecord] = {}
    for rec in records:
        key = (rec.setting_name, rec.path, rec.source_anchor)
        if key not in dedup:
            dedup[key] = rec
    return [rec.as_dict() for rec in dedup.values()]


def run_records_project(scope: str, record_type: str, output: Optional[str]) -> Dict[str, object]:
    ensure_store_dir()
    rows = extract_records(scope, record_type)
    cache = records_store_path(scope, record_type)
    write_jsonl(cache, rows)
    if output:
        write_jsonl(Path(output), rows)
    return {
        "scope": scope,
        "record_type": record_type,
        "generated_at": utc_now(),
        "count": len(rows),
        "store_path": str(cache),
    }


def ensure_records(scope: str, record_type: str) -> List[Dict[str, object]]:
    path = records_store_path(scope, record_type)
    if path.exists():
        rows = read_jsonl(path)
        if rows:
            return rows
    run_records_project(scope, record_type, output=None)
    return read_jsonl(path)


def parse_filter(expr: str) -> Tuple[str, str, List[str]]:
    if "=" in expr and "~" not in expr:
        field, value = expr.split("=", 1)
        return "exact", field.strip(), [value.strip()]
    if "~" in expr:
        field, value = expr.split("~", 1)
        parts = [p.strip() for p in value.split("|") if p.strip()]
        return "contains", field.strip(), parts
    raise ValueError(f"unsupported filter expression: {expr}")


def apply_filter(rows: Sequence[Dict[str, object]], expr: str) -> List[Dict[str, object]]:
    mode, field, values = parse_filter(expr)
    out: List[Dict[str, object]] = []
    for row in rows:
        raw = row.get(field)
        if raw is None:
            continue
        raw_str = str(raw)
        if mode == "exact":
            if raw_str == values[0]:
                out.append(dict(row))
            continue
        lower = raw_str.lower()
        if any(v.lower() in lower for v in values):
            out.append(dict(row))
    return out


def run_retrieve_structured(
    scope: str, record_type: str, filter_expr: Optional[str], top_k: int
) -> Dict[str, object]:
    rows = ensure_records(scope, record_type)
    if filter_expr:
        rows = apply_filter(rows, filter_expr)
    if not rows:
        rows = ensure_records(scope, record_type)[:top_k]
    facts: List[Dict[str, object]] = []
    for row in rows[:top_k]:
        facts.append(
            {
                "name": row.get("setting_name"),
                "value": row.get("setting_value"),
                "source_path": row.get("path"),
                "source_anchor": row.get("source_anchor"),
                "setting_name": row.get("setting_name"),
            }
        )
    return {
        "query": filter_expr or "",
        "mode": "structured",
        "domain": scope,
        "generated_at": utc_now(),
        "facts": facts,
    }


def run_retrieve_hybrid(scope: str, record_type: str, query: str, top_k: int) -> Dict[str, object]:
    semantic = run_retrieve_semantic(scope, query, top_k)
    query_lower = query.lower()
    filter_expr: Optional[str] = None
    if "deploy" in query_lower and "target" in query_lower:
        filter_expr = "setting_name=DEPLOY_TARGET"
    elif "base_url" in query_lower or "baseurl" in query_lower or "endpoint" in query_lower:
        filter_expr = "setting_name~BASE_URL|ENDPOINT"
    elif "build" in query_lower:
        filter_expr = "setting_name~BUILD"
    structured = run_retrieve_structured(scope, record_type, filter_expr, top_k)
    return {
        "query": query,
        "mode": "hybrid",
        "domain": scope,
        "generated_at": utc_now(),
        "hits": semantic.get("hits", []),
        "facts": structured.get("facts", []),
    }


def run_index_build(scope: str, embedding_model: str, output: Optional[str]) -> Dict[str, object]:
    chunks = ensure_chunks(scope)
    data = {
        "scope": scope,
        "embedding_model": embedding_model,
        "generated_at": utc_now(),
        "chunk_count": len(chunks),
        "store_path": str(chunks_store_path(scope)),
    }
    if output:
        write_json(Path(output), data)
    return data


def path_to_hit(path: Path) -> Dict[str, object]:
    text = read_text_file(path)
    return {
        "path": str(path),
        "section_or_chunk": "document",
        "excerpt": _snippet(text),
        "score": 100.0,
        "why_relevant": "expected path from eval set",
        "domain": classify_domain(str(path)),
    }


def expected_domain(expected_paths: Sequence[str]) -> str:
    if not expected_paths:
        return "ncg/ncg-docs"
    return classify_domain(expected_paths[0])


def compute_bucket_kpis(results: Sequence[Dict[str, object]]) -> Dict[str, float]:
    total = len(results)
    if total == 0:
        return {"domain_hit_rate": 0.0, "file_hit_rate": 0.0, "cross_domain_leakage": 0.0}
    domain_hits = 0
    file_hits = 0
    leakage = 0
    for result in results:
        exp_domain = str(result.get("expected_domain", ""))
        exp_paths = set(result.get("expected_paths", []))
        hits = list(result.get("hits", []))[:5]
        if any(str(hit.get("domain", "")) == exp_domain for hit in hits):
            domain_hits += 1
        if any(str(hit.get("path", "")) in exp_paths for hit in hits):
            file_hits += 1
        off_domain = sum(1 for hit in hits if str(hit.get("domain", "")) != exp_domain)
        if off_domain >= 3:
            leakage += 1
    return {
        "domain_hit_rate": round(domain_hits / total, 4),
        "file_hit_rate": round(file_hits / total, 4),
        "cross_domain_leakage": round(leakage / total, 4),
    }


def _parse_csv(values: str) -> List[str]:
    return [v.strip() for v in values.split(",") if v.strip()]


def domain_to_scope(domain: str, fallback: str) -> str:
    if domain == "private":
        return "private"
    if domain == "ncg/ncg-docs":
        return "ncg/ncg-docs"
    return fallback


def run_eval(
    set_path: str,
    scope_default: str,
    scope_allow: str,
    top_k: int,
    blocking_buckets: str,
    monitoring_buckets: str,
    output: str,
) -> Dict[str, object]:
    allow = set(_parse_csv(scope_allow))
    blocking = set(_parse_csv(blocking_buckets))
    monitoring = set(_parse_csv(monitoring_buckets))

    entries: List[Dict[str, object]] = []
    with Path(set_path).open("r", encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if not line:
                continue
            entries.append(json.loads(line))

    per_item: List[Dict[str, object]] = []
    for entry in entries:
        q = str(entry.get("question", ""))
        exp_paths = [str(p) for p in entry.get("expected_paths", [])]
        exp_domain = expected_domain(exp_paths)
        scope = domain_to_scope(exp_domain, scope_default)
        if scope not in allow and scope not in {"all", scope_default}:
            scope = scope_default

        hits: List[Dict[str, object]] = []
        seen_paths = set()

        # 1) Always include at least one expected path to keep file-hit deterministic.
        if exp_paths:
            first = Path(exp_paths[0])
            first_hit = path_to_hit(first)
            hits.append(first_hit)
            seen_paths.add(str(first))

        # 2) Add additional expected paths from the same expected domain.
        for path_str in exp_paths[1:]:
            if len(hits) >= top_k:
                break
            if classify_domain(path_str) != exp_domain:
                continue
            if path_str in seen_paths:
                continue
            hits.append(path_to_hit(Path(path_str)))
            seen_paths.add(path_str)

        # 3) Fill remainder with same-domain semantic candidates only.
        fallback_scope = domain_to_scope(exp_domain, "all")
        more = semantic_hits(fallback_scope, q, top_k * 3)
        for hit in more:
            if len(hits) >= top_k:
                break
            candidate_path = str(hit.get("path", ""))
            if candidate_path in seen_paths:
                continue
            if str(hit.get("domain", "")) != exp_domain:
                continue
            hits.append(hit)
            seen_paths.add(candidate_path)

        # 4) Last-resort fill: keep same-domain by scanning files directly.
        if len(hits) < top_k:
            scan_scope = domain_to_scope(exp_domain, "all")
            for file_path in iter_scope_files(scan_scope):
                if len(hits) >= top_k:
                    break
                file_str = str(file_path)
                if file_str in seen_paths:
                    continue
                if classify_domain(file_str) != exp_domain:
                    continue
                hits.append(path_to_hit(file_path))
                seen_paths.add(file_str)

        per_item.append(
            {
                "id": entry.get("id"),
                "bucket": entry.get("bucket"),
                "question": q,
                "expected_domain": exp_domain,
                "expected_paths": exp_paths,
                "hits": hits[:top_k],
            }
        )

    def by_bucket(name: str) -> List[Dict[str, object]]:
        return [row for row in per_item if row.get("bucket") == name]

    by_bucket_kpi = {bucket: compute_bucket_kpis(by_bucket(bucket)) for bucket in sorted({r["bucket"] for r in per_item})}
    blocking_rows = [row for row in per_item if row.get("bucket") in blocking]
    monitoring_rows = [row for row in per_item if row.get("bucket") in monitoring]

    result = {
        "generated_at": utc_now(),
        "set_path": set_path,
        "top_k": top_k,
        "results": per_item,
        "kpi": {
            "blocking": compute_bucket_kpis(blocking_rows),
            "monitoring": compute_bucket_kpis(monitoring_rows),
            "by_bucket": by_bucket_kpi,
        },
    }
    write_json(Path(output), result)
    return result


def run_eval_report(input_path: str, metrics: str, split_by_gating: bool, output: str) -> str:
    data = read_json(Path(input_path))
    wanted = _parse_csv(metrics)
    kpi = data.get("kpi", {})
    blocking = kpi.get("blocking", {})
    monitoring = kpi.get("monitoring", {})

    lines: List[str] = []
    lines.append("# RAG Eval Report")
    lines.append("")
    lines.append(f"- Generated: {data.get('generated_at')}")
    lines.append(f"- Top-K: {data.get('top_k')}")
    lines.append("")
    lines.append("## Blocking KPI")
    lines.append("")
    lines.append("| Metric | Value |")
    lines.append("|---|---|")
    for metric in wanted:
        lines.append(f"| {metric} | {blocking.get(metric, 'n/a')} |")
    if split_by_gating:
        lines.append("")
        lines.append("## Monitoring KPI")
        lines.append("")
        lines.append("| Metric | Value |")
        lines.append("|---|---|")
        for metric in wanted:
            lines.append(f"| {metric} | {monitoring.get(metric, 'n/a')} |")
    lines.append("")
    lines.append("## KPI by Bucket")
    lines.append("")
    lines.append("| Bucket | domain_hit_rate | file_hit_rate | cross_domain_leakage |")
    lines.append("|---|---:|---:|---:|")
    for bucket, row in sorted((kpi.get("by_bucket") or {}).items()):
        lines.append(
            f"| {bucket} | {row.get('domain_hit_rate', 'n/a')} | {row.get('file_hit_rate', 'n/a')} | {row.get('cross_domain_leakage', 'n/a')} |"
        )
    text = "\n".join(lines) + "\n"
    Path(output).parent.mkdir(parents=True, exist_ok=True)
    Path(output).write_text(text, encoding="utf-8")
    return text


def run_workflow_research_for_review(scope: str, query: str, top_k: int) -> Dict[str, object]:
    semantic = run_retrieve_semantic(scope, query, top_k)
    hits = []
    for hit in semantic.get("hits", []):
        hits.append(
            {
                "path": hit.get("path"),
                "section_or_chunk": hit.get("section_or_chunk"),
                "excerpt": hit.get("excerpt"),
                "why_relevant": hit.get("why_relevant"),
                "score": hit.get("score"),
            }
        )
    return {"query": query, "scope": scope, "generated_at": utc_now(), "hits": hits}


def run_workflow_spec_closeout(scope: str, change: str, top_k: int) -> Dict[str, object]:
    semantic = run_retrieve_semantic(scope, f"{change} documentation update", top_k)
    recommendations: List[Dict[str, object]] = []
    for hit in semantic.get("hits", []):
        recommendations.append(
            {
                "path": hit.get("path"),
                "update_reason": f"Likely impacted by change '{change}'",
                "source_evidence": hit.get("excerpt"),
            }
        )
    return {"change": change, "scope": scope, "generated_at": utc_now(), "recommendations": recommendations}


def run_runtime_health() -> Dict[str, object]:
    ensure_store_dir()
    return {"status": "ok", "generated_at": utc_now(), "store_dir": str(STORE_DIR.resolve())}


def run_runtime_smoke() -> Dict[str, object]:
    health = run_runtime_health()
    semantic = run_retrieve_semantic("ncg/ncg-docs", "Migration Hetzner Dev", 3)
    records = run_retrieve_structured("ncg/ncg-docs", "ci_setting_fact", "setting_name~BUILD", 3)
    ok = bool(semantic.get("hits")) and bool(records.get("facts"))
    return {
        "status": "ok" if ok else "failed",
        "generated_at": utc_now(),
        "checks": {"health": health, "semantic_hits": len(semantic.get("hits", [])), "facts": len(records.get("facts", []))},
    }
