from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from rag_runtime import __version__
from rag_runtime.core import (
    run_eval,
    run_eval_report,
    run_index_build,
    run_ingest,
    run_inspect_chunks,
    run_records_project,
    run_retrieve_hybrid,
    run_retrieve_semantic,
    run_retrieve_structured,
    run_runtime_health,
    run_runtime_smoke,
    run_workflow_research_for_review,
    run_workflow_spec_closeout,
)


def print_json(data: object) -> None:
    print(json.dumps(data, ensure_ascii=False, indent=2))


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="rag", description="DanielsVault RAG CLI")
    parser.add_argument("--version", action="version", version=f"rag {__version__}")
    sub = parser.add_subparsers(dest="command")

    ingest = sub.add_parser("ingest")
    ingest_sub = ingest.add_subparsers(dest="subcommand")
    ingest_run = ingest_sub.add_parser("run")
    ingest_run.add_argument("--scope", required=True)
    ingest_run.add_argument("--output")
    ingest_run.add_argument("--dry-run", action="store_true")
    ingest_run.add_argument("--list-files", action="store_true")

    inspect = sub.add_parser("inspect")
    inspect_sub = inspect.add_subparsers(dest="subcommand")
    inspect_chunks = inspect_sub.add_parser("chunks")
    inspect_chunks.add_argument("--scope", required=True)
    inspect_chunks.add_argument("--limit", type=int, default=20)
    inspect_chunks.add_argument("--require-fields")

    retrieve = sub.add_parser("retrieve")
    retrieve_sub = retrieve.add_subparsers(dest="subcommand")
    retrieve_semantic = retrieve_sub.add_parser("semantic")
    retrieve_semantic.add_argument("--scope", required=True)
    retrieve_semantic.add_argument("--query", required=True)
    retrieve_semantic.add_argument("--top-k", type=int, default=5)
    retrieve_semantic.add_argument("--format", default="json")

    retrieve_structured = retrieve_sub.add_parser("structured")
    retrieve_structured.add_argument("--scope", required=True)
    retrieve_structured.add_argument("--record-type", required=True)
    retrieve_structured.add_argument("--filter")
    retrieve_structured.add_argument("--top-k", type=int, default=5)
    retrieve_structured.add_argument("--format", default="json")

    retrieve_hybrid = retrieve_sub.add_parser("hybrid")
    retrieve_hybrid.add_argument("--scope", required=True)
    retrieve_hybrid.add_argument("--record-type", required=True)
    retrieve_hybrid.add_argument("--query", required=True)
    retrieve_hybrid.add_argument("--top-k", type=int, default=5)
    retrieve_hybrid.add_argument("--format", default="json")

    records = sub.add_parser("records")
    records_sub = records.add_subparsers(dest="subcommand")
    records_project = records_sub.add_parser("project")
    records_project.add_argument("--scope", required=True)
    records_project.add_argument("--record-type", required=True)
    records_project.add_argument("--output")

    index = sub.add_parser("index")
    index_sub = index.add_subparsers(dest="subcommand")
    index_build = index_sub.add_parser("build")
    index_build.add_argument("--scope", required=True)
    index_build.add_argument("--embedding-model", required=True)
    index_build.add_argument("--output")

    eval_parser = sub.add_parser("eval")
    eval_sub = eval_parser.add_subparsers(dest="subcommand")
    eval_run = eval_sub.add_parser("run")
    eval_run.add_argument("--set", required=True)
    eval_run.add_argument("--scope-default", required=True)
    eval_run.add_argument("--scope-allow", required=True)
    eval_run.add_argument("--top-k", type=int, default=5)
    eval_run.add_argument("--blocking-buckets", required=True)
    eval_run.add_argument("--monitoring-buckets", required=True)
    eval_run.add_argument("--output", required=True)

    eval_report = eval_sub.add_parser("report")
    eval_report.add_argument("--input", required=True)
    eval_report.add_argument("--metrics", required=True)
    eval_report.add_argument("--split-by-gating", action="store_true")
    eval_report.add_argument("--output", required=True)

    workflow = sub.add_parser("workflow")
    workflow_sub = workflow.add_subparsers(dest="subcommand")
    workflow_review = workflow_sub.add_parser("research-for-review")
    workflow_review.add_argument("--scope", required=True)
    workflow_review.add_argument("--query", required=True)
    workflow_review.add_argument("--top-k", type=int, default=5)
    workflow_review.add_argument("--format", default="json")

    workflow_closeout = workflow_sub.add_parser("spec-closeout")
    workflow_closeout.add_argument("--scope", required=True)
    workflow_closeout.add_argument("--change", required=True)
    workflow_closeout.add_argument("--top-k", type=int, default=5)
    workflow_closeout.add_argument("--format", default="json")

    runtime = sub.add_parser("runtime")
    runtime_sub = runtime.add_subparsers(dest="subcommand")
    runtime_sub.add_parser("health")
    runtime_sub.add_parser("smoke")

    return parser


def _print_or_write_text(path: str, text: str) -> None:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(text, encoding="utf-8")


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    try:
        if args.command == "ingest" and args.subcommand == "run":
            data = run_ingest(args.scope, args.output, args.dry_run, args.list_files)
            if not args.list_files:
                print_json(data)
            return 0

        if args.command == "inspect" and args.subcommand == "chunks":
            print_json(run_inspect_chunks(args.scope, args.limit, args.require_fields))
            return 0

        if args.command == "retrieve" and args.subcommand == "semantic":
            print_json(run_retrieve_semantic(args.scope, args.query, args.top_k))
            return 0

        if args.command == "retrieve" and args.subcommand == "structured":
            print_json(run_retrieve_structured(args.scope, args.record_type, args.filter, args.top_k))
            return 0

        if args.command == "retrieve" and args.subcommand == "hybrid":
            print_json(run_retrieve_hybrid(args.scope, args.record_type, args.query, args.top_k))
            return 0

        if args.command == "records" and args.subcommand == "project":
            print_json(run_records_project(args.scope, args.record_type, args.output))
            return 0

        if args.command == "index" and args.subcommand == "build":
            print_json(run_index_build(args.scope, args.embedding_model, args.output))
            return 0

        if args.command == "eval" and args.subcommand == "run":
            print_json(
                run_eval(
                    set_path=args.set,
                    scope_default=args.scope_default,
                    scope_allow=args.scope_allow,
                    top_k=args.top_k,
                    blocking_buckets=args.blocking_buckets,
                    monitoring_buckets=args.monitoring_buckets,
                    output=args.output,
                )
            )
            return 0

        if args.command == "eval" and args.subcommand == "report":
            text = run_eval_report(args.input, args.metrics, args.split_by_gating, args.output)
            print(text, end="")
            return 0

        if args.command == "workflow" and args.subcommand == "research-for-review":
            print_json(run_workflow_research_for_review(args.scope, args.query, args.top_k))
            return 0

        if args.command == "workflow" and args.subcommand == "spec-closeout":
            print_json(run_workflow_spec_closeout(args.scope, args.change, args.top_k))
            return 0

        if args.command == "runtime" and args.subcommand == "health":
            print_json(run_runtime_health())
            return 0

        if args.command == "runtime" and args.subcommand == "smoke":
            data = run_runtime_smoke()
            print_json(data)
            return 0 if data.get("status") == "ok" else 1

        parser.print_help()
        return 1
    except Exception as exc:  # pragma: no cover - command-level safety net
        print(json.dumps({"error": str(exc)}, ensure_ascii=False), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
