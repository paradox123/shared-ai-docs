# Scope Contract

## Change
- Id: `2026-04-22-rag-spec-hardening`
- Mode: `openspec`
- Source Findings: P1/P2 Review Findings 1-4 (Ingestion, Structured Projections, Retrieval, Agent Integration)

## Goal (1-2 Saetze)
Die Spec-Verifikation wird gegen vacuous-pass-Muster gehaertet und die Filter-Semantik fuer strukturierte Retrieval-Filter verbindlich gemacht. Damit werden falsch-gruene Abnahmen reduziert, ohne den RAG-Runtime-Umfang zu erweitern.

## In Scope
1. `_specs/2026-04-21 01 DanielsVault RAG Ingestion Scope und Metadaten.md`
2. `_specs/2026-04-21 02 DanielsVault RAG Strukturierte Projektionen.md`
3. `_specs/2026-04-21 03 DanielsVault RAG Embeddings Index und Hybrides Retrieval.md`
4. `_specs/2026-04-21 05 DanielsVault RAG Agent Integration Research-for-Review und Spec-Closeout.md`
5. Ausfuehrung und Protokollierung aller in `01..05` definierten Verifikationskommandos mit `ran/failed/blocked` Status.
6. Build-Watcher Statusnachweis via `check-build.local.watch.cs -- --show-state`.

## Out of Scope
1. Implementierung oder Installation einer `rag` CLI/runtime.
2. Infrastruktur-/Docker-Runtime fuer ein noch nicht vorhandenes RAG-Service.
3. Funktionsimplementierung ausserhalb der vier Review Findings.

## Acceptance Targets
1. `01`: Scope-Gate darf nicht ohne Treffer bestehen (`assert hits`) und prueft Leakage danach.
2. `03`: Scope-Test prueft beide Seiten (Default und Private-Override) inkl. non-empty Assertions.
3. `05`: Workflow-Pruefung fordert non-empty `hits`/`recommendations` vor Feldvalidierung.
4. `02`: Operator-Semantik fuer `=`, `~`, `~A|B` ist explizit und normativ dokumentiert.
5. Verifikationskommandos aus `01..05` wurden ausgefuehrt und je Kommando mit Status erfasst.

## Planned Verification
1. Ausfuehrung aller Verifikationscommand-Blöcke aus Specs `01..05` im Zielprojekt:
   - `/Users/dh/Documents/DanielsVault/_shared/danielsvault-rag`
2. Nachweisdatei:
   - `/Users/dh/Documents/DanielsVault/_shared/danielsvault-rag/.rag/status/verification-status-2026-04-22-open-spec.txt`
3. Build-Watcher Nachweis:
   - `/tmp/check_build_watcher_show_state.log`
