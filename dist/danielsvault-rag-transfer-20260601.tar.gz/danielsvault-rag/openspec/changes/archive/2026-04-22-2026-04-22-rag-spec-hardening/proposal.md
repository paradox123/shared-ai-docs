# Proposal: Harden RAG Spec Verification Gates

## Why
Recent review findings identified weak verification checks that could pass vacuously (zero-hit passes, non-discriminative scope tests, empty workflow outputs, underspecified structured filter semantics).

## What
1. Harden scope-gate checks with non-empty assertions.
2. Make default-vs-private verification bidirectional and discriminative.
3. Require non-empty workflow outputs before field-level checks.
4. Define binding filter operator semantics for structured retrieval.

## Impact
- Stronger acceptance quality at spec level.
- Reduced risk of false-green verification.
- Clearer implementation contract for retrieval filtering.

## Out of Scope
- Implementing the RAG runtime/CLI itself.
- Runtime docker-compose health validation for a non-existing service.

## Scope Contract Reference
- `/Users/dh/Documents/DanielsVault/_shared/danielsvault-rag/openspec/changes/2026-04-22-rag-spec-hardening/scope-contract.md`
