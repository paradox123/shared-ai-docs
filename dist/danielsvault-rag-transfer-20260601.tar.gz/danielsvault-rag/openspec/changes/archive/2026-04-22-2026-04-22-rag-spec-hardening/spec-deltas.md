# Spec Deltas

## 01 Ingestion
- Added `assert hits` before leakage assertion to prevent vacuous pass.

## 02 Structured Projections
- Added binding filter grammar:
  - `field=value` exact match (case-sensitive)
  - `field~value` case-insensitive substring
  - `field~A|B` OR over case-insensitive substrings
- Added normative rule that no additional operators are implicitly guaranteed in Phase 1.

## 03 Embeddings/Hybrid Retrieval
- Added non-empty assertions for both default and private override retrieval.
- Added private-domain inclusion assertion for override path.

## 05 Agent Integration
- Added non-empty assertions for workflow `hits` and `recommendations` before field checks.

## Verification Evidence
- Spec verification status log:
  - `/Users/dh/Documents/DanielsVault/_shared/danielsvault-rag/.rag/status/verification-status-2026-04-22-open-spec.txt`
- Build watcher state log:
  - `/tmp/check_build_watcher_show_state.log`
