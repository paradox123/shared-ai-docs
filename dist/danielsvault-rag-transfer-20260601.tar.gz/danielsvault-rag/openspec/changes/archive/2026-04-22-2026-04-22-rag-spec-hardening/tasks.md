# Tasks

- [x] Define Scope Contract with in/out scope, acceptance targets, and planned verification.
- [x] Harden `_specs/2026-04-21 01 DanielsVault RAG Ingestion Scope und Metadaten.md` scope-gate verification with non-empty hit assertion.
- [x] Harden `_specs/2026-04-21 03 DanielsVault RAG Embeddings Index und Hybrides Retrieval.md` with explicit default and private override assertions.
- [x] Harden `_specs/2026-04-21 05 DanielsVault RAG Agent Integration Research-for-Review und Spec-Closeout.md` with non-empty `hits` and `recommendations` assertions.
- [x] Define filter operator semantics in `_specs/2026-04-21 02 DanielsVault RAG Strukturierte Projektionen.md`.
- [x] Execute all spec verification commands and capture `ran/failed/blocked` statuses.
- [x] Capture build watcher state using `check-build.local.watch.cs -- --show-state`.
- [x] Publish acceptance matrix and implementation evidence.
- [ ] Resolve blocked verification caused by missing `rag` CLI/runtime implementation.
- [ ] Execute runtime validation (`compose + health`) once runtime exists.
