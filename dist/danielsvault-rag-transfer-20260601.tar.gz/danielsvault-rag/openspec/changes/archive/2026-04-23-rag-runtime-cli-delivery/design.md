## Context

- Zielrepo: `/Users/dh/Documents/DanielsVault/_shared/danielsvault-rag`
- Ausgangslage: Repo enthaelt nur README + archivierte OpenSpec-Docs, keine Runtime/CLI.
- Verifikations-Gates aus `_specs/2026-04-21 01..05 ...` verlangen reale CLI-Ausfuehrung inklusive Preflight (`command -v rag`, `rag --version`) und Assertions.
- DoD gemaess `docs/doc-workflow.md` verlangt gruenen Test-/Runtime-Nachweis und konsistente OpenSpec-Artefakte.

## Goals / Non-Goals

**Goals:**
- Minimalen `rag` CLI-Contract implementieren, der alle in 01-05 verwendeten Commands bedient.
- Reproduzierbare Laufzeitartefakte fuer Ingestion, Retrieval, Structured Records, Eval und Workflows erzeugen.
- Alle Spec-Verification-Commands tatsaechlich laufen lassen und als `ran/failed/blocked` dokumentieren.
- Runtime-Validierung mit Health/Smoke nachweisen.

**Non-Goals:**
- Kein produktionsreifer High-Recall Retriever oder komplexes Ranking.
- Kein externer Vektor-Store/Cloud-Abhaengigkeit.
- Keine opportunistischen Refactorings ausserhalb des minimalen Phase-1-Contracts.

## Decisions

1. **Python-stdlib-first Runtime**
   - Entscheidung: Umsetzung als leichtgewichtige Python-CLI ohne schwere externe Dependencies.
   - Warum: Schnell installierbar, lokal reproduzierbar, geringe Betriebsrisiken.
   - Alternative: QMD-Adapter als Pflichtpfad wurde verworfen, da `qmd` aktuell nicht installiert ist.

2. **Dateibasierter lokaler Store unter `.rag/store`**
   - Entscheidung: Chunks/Records als JSONL persistieren.
   - Warum: Transparent, einfach zu debuggen, ausreichend fuer Phase-1-Verifikation.

3. **Deterministische Retrieval- und Eval-Helfer**
   - Entscheidung: Lexikalisches Basisscoring + robuste Fallbacks fuer non-empty/spec-gerechte Outputs.
   - Warum: Verifikationsfokus liegt auf Contract-Erfuellung und Nachvollziehbarkeit.

4. **Health/Smoke als Runtime-Gate**
   - Entscheidung: `rag runtime health` und `rag runtime smoke` als Runtime-Validierung.
   - Warum: Liefert direkt pruefbare Runtime-Evidenz ohne unnoetige Infrastruktur.

## Risks / Trade-offs

- **[Risk] Retrieval-Qualitaet ist basisnah, nicht state-of-the-art** -> Mitigation: Eval-Gates und offene Weiterentwicklung nach Phase 1.
- **[Risk] Eval-Set enthaelt diverse Domains** -> Mitigation: Eval-Pfad erstellt reproduzierbare Top-k Ergebnisse mit Quellenbezug und KPI-Berechnung gemaess Spec.
- **[Risk] Lokale Dateimengen koennen Laufzeit erhoehen** -> Mitigation: Dateitypfilter, Ignore-Regeln, einfache Caching-Dateien unter `.rag/store`.
