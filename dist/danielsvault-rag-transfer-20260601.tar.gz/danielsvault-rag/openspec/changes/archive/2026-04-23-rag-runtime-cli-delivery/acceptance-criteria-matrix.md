# Acceptance Criteria Matrix

| Criterion | Status | Evidence |
|---|---|---|
| CLI preflight (`command -v rag`, `rag --version`) passes | pass | `/Users/dh/Documents/DanielsVault/_shared/danielsvault-rag/.rag/status/verification-status-2026-04-23-runtime-open-spec.txt` (`01_02`..`01_04`, `02_02`..`02_04`, `03_02`..`03_04`, `04_02`..`04_04`, `05_02`..`05_04`) |
| Spec 01 verification block fully green | pass | `/Users/dh/Documents/DanielsVault/_shared/danielsvault-rag/.rag/status/verification-status-2026-04-23-runtime-open-spec.txt` (`01_01`..`01_11` all `ran`) |
| Spec 02 verification block fully green | pass | `/Users/dh/Documents/DanielsVault/_shared/danielsvault-rag/.rag/status/verification-status-2026-04-23-runtime-open-spec.txt` (`02_01`..`02_09` all `ran`) |
| Spec 03 verification block fully green | pass | `/Users/dh/Documents/DanielsVault/_shared/danielsvault-rag/.rag/status/verification-status-2026-04-23-runtime-open-spec.txt` (`03_01`..`03_10` all `ran`) |
| Spec 04 verification block fully green | pass | `/Users/dh/Documents/DanielsVault/_shared/danielsvault-rag/.rag/status/verification-status-2026-04-23-runtime-open-spec.txt` (`04_01`..`04_07` all `ran`) |
| Spec 05 verification block fully green | pass | `/Users/dh/Documents/DanielsVault/_shared/danielsvault-rag/.rag/status/verification-status-2026-04-23-runtime-open-spec.txt` (`05_01`..`05_09` all `ran`) |
| Runtime validation (`rag runtime health`, `rag runtime smoke`) green | pass | `/Users/dh/Documents/DanielsVault/_shared/danielsvault-rag/.rag/status/runtime-health-2026-04-23.json`, `/Users/dh/Documents/DanielsVault/_shared/danielsvault-rag/.rag/status/runtime-smoke-2026-04-23.json` |
| check-build-watcher evidence captured | pass | `/Users/dh/Documents/DanielsVault/_shared/danielsvault-rag/.rag/status/check-build-watcher-2026-04-23.log` |
| OpenSpec tasks complete without blocked-as-done | pass | `/Users/dh/Documents/DanielsVault/_shared/danielsvault-rag/openspec/changes/rag-runtime-cli-delivery/tasks.md`, `openspec status --change rag-runtime-cli-delivery --json` |
