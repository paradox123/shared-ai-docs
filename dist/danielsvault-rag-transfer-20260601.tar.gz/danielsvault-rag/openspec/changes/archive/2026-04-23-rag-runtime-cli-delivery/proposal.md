## Why

Die aktuelle RAG-Spezifikation ist gehaertet, aber die Runtime fehlt: `rag` CLI ist nicht installiert, Verifikation ist deshalb `blocked/failed` statt gruen. Fuer belastbare Abnahme muss eine minimale lauffaehige CLI/Runtime existieren, die die Commands aus Child-Specs 01-05 real ausfuehrt.

## What Changes

- Implementierung einer minimalen, lauffaehigen `rag` CLI mit den Kommandogruppen `ingest`, `inspect`, `retrieve`, `records`, `index`, `eval`, `workflow`.
- Implementierung eines lokalen Runtime-Kerns fuer Dateiquellen, Chunking, Metadaten, semantisches/strukturiertes/hybrides Retrieval.
- Implementierung von Eval-Run und Report-Ausgabe gemaess Child-Spec 04 inkl. KPI-Berechnung.
- Implementierung von Runtime-Health/Smoke-Kommandos als Runtime-Validierung.
- Ausfuehrung und Protokollierung aller Verifikationskommandos aus Specs 01-05 mit Status je Kommando.
- Build-Monitoring-Nachweis ueber `check-build-watcher` (`--show-state`).

## Capabilities

### New Capabilities
- `rag-cli-runtime`: Minimaler CLI/Runtime-Contract fuer DanielsVault-RAG Phase 1 inkl. Verifikationsfaehigkeit gemaess Specs 01-05.

### Modified Capabilities
- None.

## Impact

- Neuer Python-Code im Zielprojekt fuer CLI + Runtime.
- Neue lokale Laufzeitartefakte unter `.rag/` (Index, Runs, Eval-Outputs, Verifikationslogs).
- Neuer OpenSpec-Change mit Proposal/Design/Specs/Tasks und Evidence-Artefakten.
