## 1. OpenSpec Planning and Scope Contract

- [x] 1.1 Document pre-implementation analysis (markers, code reality, contradictions).
- [x] 1.2 Create scope contract with in/out scope, acceptance targets, and planned verification.
- [x] 1.3 Keep proposal/design/spec-deltas aligned to the same scope.

## 2. Runtime and CLI Implementation

- [x] 2.1 Scaffold Python package and `rag` console entrypoint.
- [x] 2.2 Implement ingestion/index/chunk inspection with required metadata and scope mapping.
- [x] 2.3 Implement structured projection and filter semantics (`=`, `~`, `~A|B`).
- [x] 2.4 Implement semantic and hybrid retrieval with required output envelope fields.
- [x] 2.5 Implement eval run/report and workflow commands (`research-for-review`, `spec-closeout`).
- [x] 2.6 Implement runtime health/smoke commands.

## 3. Tests and Verification

- [x] 3.1 Add focused tests (TDD where practical) for filter semantics and KPI calculations.
- [x] 3.2 Execute all verification commands from specs 01-05 and record per-command status (`ran/failed/blocked`).
- [x] 3.3 Execute check-build-watcher show-state and persist evidence.
- [x] 3.4 Execute runtime validation (`rag runtime health`, `rag runtime smoke`) and persist evidence.

## 4. Evidence and DoD Closeout

- [x] 4.1 Produce acceptance criteria matrix with pass/fail evidence links.
- [x] 4.2 Produce implementation evidence report with full verification checklist and outcomes.
- [x] 4.3 Complete all tasks and confirm no `[BLOCKED]` task is marked done.
