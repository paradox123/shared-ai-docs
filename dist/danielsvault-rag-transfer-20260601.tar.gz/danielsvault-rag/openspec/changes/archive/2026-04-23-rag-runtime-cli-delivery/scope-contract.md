# Scope Contract

## Change
- Id: `rag-runtime-cli-delivery`
- Mode: `openspec`
- Source: Child-Spec verification gates 01-05 + Parent gate hardening (rag preflight + no blocked-as-pass)

## Pre-Implementation Analysis

### Formal Marker Check
- Checked specs:
  - `/Users/dh/Documents/DanielsVault/_shared/shared-ai-docs/_specs/2026-04-13 DanielsVault Local RAG Wissensplattform.md`
  - `/Users/dh/Documents/DanielsVault/_shared/shared-ai-docs/_specs/2026-04-21 01..05 ...`
- Result:
  - No `[MISSING]`, `[DECISION]`, `[BLOCKED]` markers found.
  - Two `[REVIEW ...]` markers in parent are explicit non-blocking follow-ups.

### Codebase Reality
- Target repo currently has no runtime implementation (only README + archived openspec evidence).
- `rag` CLI is not installed/available from repo state.
- Runtime artifacts (`Dockerfile`, compose stack, service code) are absent.

### Spec/Code Consistency
- No hard contradiction preventing implementation.
- Work required: full minimal runtime/CLI to satisfy verification contracts 01-05.

## Goal (1-2 Sätze)
Implement a minimal runnable `rag` CLI/runtime that executes all spec verification commands (01-05) successfully with real runtime outcomes and complete evidence. Keep implementation bounded to required contract behavior only.

## In Scope
1. Python CLI runtime in `/Users/dh/Documents/DanielsVault/_shared/danielsvault-rag` implementing commands used by specs 01-05.
2. Local ingestion/index/chunk metadata handling for scopes `ncg/ncg-docs`, `private`, `all`.
3. Structured projections (`ci_setting_fact`) and required filter semantics.
4. Semantic/hybrid retrieval envelopes and workflow outputs.
5. Eval run/report with blocking KPI checks.
6. Runtime validation commands (`rag runtime health`, `rag runtime smoke`).
7. Full verification replay from specs 01-05 with per-command status and evidence logs.
8. `check-build-watcher` execution (`--show-state`) with evidence log.
9. OpenSpec artifacts: proposal, design, specs delta, tasks, acceptance matrix, implementation evidence.

## Out of Scope
1. Advanced ranking quality tuning or production-grade retrieval optimization.
2. External vector DB/service orchestration beyond minimal local runtime.
3. Unrelated refactors in other repositories.

## Acceptance Targets
1. `command -v rag` and `rag --version` preflight passes in verification flow.
2. All commands from child specs 01-05 run with status `ran` (no `failed`/`blocked`).
3. Assertions embedded in spec verification blocks pass.
4. Runtime validation (`health` + `smoke`) succeeds.
5. OpenSpec tasks complete with no blocked task marked done.
6. Acceptance matrix and implementation evidence contain concrete file/log references.

## Planned Verification
1. Execute all verification command blocks from:
   - `.../2026-04-21 01 DanielsVault RAG Ingestion Scope und Metadaten.md`
   - `.../2026-04-21 02 DanielsVault RAG Strukturierte Projektionen.md`
   - `.../2026-04-21 03 DanielsVault RAG Embeddings Index und Hybrides Retrieval.md`
   - `.../2026-04-21 04 DanielsVault RAG Evaluation und Qualitaetsgates.md`
   - `.../2026-04-21 05 DanielsVault RAG Agent Integration Research-for-Review und Spec-Closeout.md`
2. Persist verification status table:
   - `/Users/dh/Documents/DanielsVault/_shared/danielsvault-rag/.rag/status/verification-status-2026-04-23-runtime-open-spec.txt`
3. Persist command logs:
   - `/Users/dh/Documents/DanielsVault/_shared/danielsvault-rag/.rag/status/commands-2026-04-23-runtime-open-spec/`
4. Build watcher evidence:
   - `/Users/dh/Documents/DanielsVault/_shared/danielsvault-rag/.rag/status/check-build-watcher-2026-04-23.log`
5. Runtime validation evidence:
   - `/Users/dh/Documents/DanielsVault/_shared/danielsvault-rag/.rag/status/runtime-health-2026-04-23.json`
   - `/Users/dh/Documents/DanielsVault/_shared/danielsvault-rag/.rag/status/runtime-smoke-2026-04-23.json`
