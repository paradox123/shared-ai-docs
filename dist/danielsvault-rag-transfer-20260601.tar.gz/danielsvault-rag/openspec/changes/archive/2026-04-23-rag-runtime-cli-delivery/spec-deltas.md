# Spec Deltas

## New Capability: rag-cli-runtime

This change introduces a concrete runtime implementation for the existing DanielsVault RAG phase-1 contract.

### Delta Summary
- Adds runnable `rag` CLI commands required by child specs 01-05.
- Adds local runtime data handling for ingestion, chunk metadata, structured facts, retrieval, eval, and workflow routes.
- Adds runtime health/smoke commands for explicit runtime validation.
- Keeps scope and gate semantics aligned with parent/child specs; no gate weakening.
