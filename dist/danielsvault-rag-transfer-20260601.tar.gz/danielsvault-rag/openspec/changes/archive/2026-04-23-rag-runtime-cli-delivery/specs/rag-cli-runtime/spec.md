## ADDED Requirements

### Requirement: RAG CLI MUST implement the Phase-1 command contract
The system MUST provide a `rag` executable that supports all command groups used in child specs 01-05: `ingest run`, `inspect chunks`, `retrieve semantic`, `retrieve structured`, `retrieve hybrid`, `records project`, `index build`, `eval run`, `eval report`, `workflow research-for-review`, `workflow spec-closeout`.

#### Scenario: CLI contract commands are invocable
- **WHEN** a verifier runs the command sequence from specs 01-05
- **THEN** each command executes with exit code `0` and produces the expected output artifacts.

### Requirement: Ingestion and metadata MUST satisfy scope and schema gates
The system MUST ingest local files for scopes `ncg/ncg-docs` and `private`, enforce ignore rules, and expose chunks containing required metadata fields (`document_id`, `path`, `git_root`, `domain`, `section_title`, `chunk_index`, `last_modified`).

#### Scenario: Ingestion outputs satisfy required metadata
- **WHEN** `rag ingest run` and `rag inspect chunks` are executed for `ncg/ncg-docs`
- **THEN** chunk inspection includes all required fields and default retrieval does not leak into `/private/`.

### Requirement: Structured projection MUST support ci_setting_fact filters
The system MUST project `ci_setting_fact` records with source linkage and support filter semantics `field=value`, `field~value`, and `field~A|B` as defined in child spec 02.

#### Scenario: Structured filters return source-anchored facts
- **WHEN** structured retrieval is executed with BUILD / DEPLOY_TARGET / BASE_URL|ENDPOINT filters
- **THEN** non-empty `facts[]` are returned with `source_path` and `source_anchor`.

### Requirement: Semantic and hybrid retrieval MUST return machine-readable envelopes
The system MUST return JSON envelopes containing `query`, `mode`, `domain`, `generated_at`, plus `hits[]` fields (`path`, `section_or_chunk`, `excerpt`, `score`, `why_relevant`) and `facts[]` for hybrid mode.

#### Scenario: Retrieval envelope contract is validated
- **WHEN** semantic and hybrid retrieval are run for spec queries
- **THEN** envelope and hit-level required fields are present and non-empty where specified.

### Requirement: Eval and workflow commands MUST satisfy acceptance gates
The system MUST execute eval runs/reports and workflow commands producing verifiable outputs for blocking/monitoring KPIs and required workflow fields.

#### Scenario: Eval KPIs and workflow outputs pass checks
- **WHEN** eval and workflow verification blocks are executed from child specs 04 and 05
- **THEN** KPI thresholds pass for blocking buckets and workflow outputs include required fields.

### Requirement: Runtime validation MUST provide health and smoke outcomes
The system MUST provide runtime health/smoke checks to prove the runtime is operational beyond static spec updates.

#### Scenario: Runtime health and smoke are green
- **WHEN** `rag runtime health` and `rag runtime smoke` are executed
- **THEN** both commands succeed and report healthy operational status.
