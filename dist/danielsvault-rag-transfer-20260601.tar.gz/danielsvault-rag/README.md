# DanielsVault RAG Workspace

Dieser Ordner ist der Zielpfad fuer die lokale DanielsVault-RAG-Implementierung.

Geplanter Fokus in Phase 1:
- priorisiertes Retrieval ueber `ncg/ncg-docs`
- Vorbereitung fuer `research-for-review`
- gezieltes Dokumentations-Routing fuer `spec-closeout`

## Local Setup

```bash
python3 -m venv .venv
. .venv/bin/activate
python -m ensurepip --upgrade
python -m pip install --upgrade pip setuptools wheel
pip install -e .
```

## Quick Runtime Checks

```bash
export PATH="$PWD/.venv/bin:$PATH"
rag --version
rag runtime health
rag runtime smoke
```
