# DanielsVault RAG Transfer Deployment

This bundle contains the local DanielsVault RAG runtime, its current `.rag` store, supporting RAG docs, and Codex skill files used to call the runtime.

## Contents

- `danielsvault-rag/`: Python CLI runtime that provides the `rag` command.
- `danielsvault-rag/.rag/store/`: current generated chunk and structured-record stores.
- `danielsvault-rag/.rag/status/` and `.rag/eval/`: verification evidence and eval outputs.
- `shared-ai-docs-rag-docs/`: RAG documentation copied from `shared-ai-docs/docs/rag`.
- `codex-skills/`: RAG and QMD skill instructions for Codex.

The generated store includes indexed excerpts from the current vault, including private-scope chunks. Treat the archive like sensitive local data.

## Target Machine Requirements

- Python 3.9 or newer.
- A local checkout/copy of `DanielsVault` if you want to re-ingest or refresh the store.
- Optional: Node.js/npm if you also want the QMD helper (`npm install -g @tobilu/qmd`).

## Install

From the directory where you extracted the archive:

```bash
cd danielsvault-rag
python3 -m venv .venv
. .venv/bin/activate
python -m ensurepip --upgrade
python -m pip install --upgrade pip setuptools wheel
pip install -e .
```

Make the command available in the current shell:

```bash
export PATH="$PWD/.venv/bin:$PATH"
```

If the vault is not located at `/Users/dh/Documents/DanielsVault` on the new machine, set:

```bash
export DANIELSVAULT_ROOT="/path/to/DanielsVault"
```

If you want the RAG store somewhere other than `danielsvault-rag/.rag/store`, set:

```bash
export RAG_STORE_DIR="$PWD/.rag/store"
```

## Verify

```bash
rag --version
rag runtime health
rag runtime smoke
```

The smoke command expects either the included store or a reachable vault at `DANIELSVAULT_ROOT`.

## Refresh The Store

After copying the full vault to the target machine, rebuild chunks and records with:

```bash
rag ingest run --scope ncg/ncg-docs
rag records project --scope ncg/ncg-docs --record-type ci_setting_fact
rag ingest run --scope private
rag ingest run --scope all
```

Useful retrieval checks:

```bash
rag retrieve semantic --scope ncg/ncg-docs --query "Migration Hetzner Dev" --top-k 5 --format json
rag retrieve structured --scope ncg/ncg-docs --record-type ci_setting_fact --filter "setting_name~BUILD" --top-k 5 --format json
rag workflow research-for-review --scope ncg/ncg-docs --query "deployment documentation" --top-k 5 --format json
```

## Optional QMD

QMD is a separate optional markdown discovery helper:

```bash
npm install -g @tobilu/qmd
qmd collection add "$DANIELSVAULT_ROOT/_shared/shared-ai-docs" --name shared-ai-docs
qmd embed
qmd query "RAG operating model" -c shared-ai-docs
```

## Codex Skill Notes

The included `codex-skills/rag-documentation-research/SKILL.md` expects the runtime at:

```text
~/Documents/DanielsVault/_shared/danielsvault-rag
```

If you install it elsewhere, update the skill preflight path or create a symlink:

```bash
mkdir -p ~/Documents/DanielsVault/_shared
ln -s /path/to/extracted/danielsvault-rag ~/Documents/DanielsVault/_shared/danielsvault-rag
```

