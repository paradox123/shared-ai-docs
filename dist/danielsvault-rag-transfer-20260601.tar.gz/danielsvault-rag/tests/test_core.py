import unittest

from rag_runtime.core import apply_filter, compute_bucket_kpis, parse_filter


class FilterSemanticsTests(unittest.TestCase):
    def test_parse_exact(self) -> None:
        mode, field, values = parse_filter("setting_name=DEPLOY_TARGET")
        self.assertEqual(mode, "exact")
        self.assertEqual(field, "setting_name")
        self.assertEqual(values, ["DEPLOY_TARGET"])

    def test_parse_substring_or(self) -> None:
        mode, field, values = parse_filter("setting_name~BASE_URL|ENDPOINT")
        self.assertEqual(mode, "contains")
        self.assertEqual(field, "setting_name")
        self.assertEqual(values, ["BASE_URL", "ENDPOINT"])

    def test_apply_filter_exact_case_sensitive(self) -> None:
        rows = [
            {"setting_name": "DEPLOY_TARGET"},
            {"setting_name": "deploy_target"},
        ]
        out = apply_filter(rows, "setting_name=DEPLOY_TARGET")
        self.assertEqual(len(out), 1)
        self.assertEqual(out[0]["setting_name"], "DEPLOY_TARGET")

    def test_apply_filter_contains_case_insensitive(self) -> None:
        rows = [
            {"setting_name": "Api_Base_Url"},
            {"setting_name": "DEPLOY_TARGET"},
        ]
        out = apply_filter(rows, "setting_name~base_url")
        self.assertEqual(len(out), 1)
        self.assertEqual(out[0]["setting_name"], "Api_Base_Url")


class KpiTests(unittest.TestCase):
    def test_bucket_kpis(self) -> None:
        results = [
            {
                "expected_domain": "ncg/ncg-docs",
                "expected_paths": ["/a.md"],
                "hits": [
                    {"path": "/a.md", "domain": "ncg/ncg-docs"},
                    {"path": "/x.md", "domain": "private"},
                ],
            },
            {
                "expected_domain": "private",
                "expected_paths": ["/p.md"],
                "hits": [
                    {"path": "/q.md", "domain": "private"},
                    {"path": "/r.md", "domain": "private"},
                    {"path": "/s.md", "domain": "private"},
                    {"path": "/t.md", "domain": "private"},
                    {"path": "/u.md", "domain": "private"},
                ],
            },
        ]
        kpis = compute_bucket_kpis(results)
        self.assertGreaterEqual(kpis["domain_hit_rate"], 0.5)
        self.assertLessEqual(kpis["cross_domain_leakage"], 1.0)


if __name__ == "__main__":
    unittest.main()
