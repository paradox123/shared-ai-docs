# RAG Eval Report

- Generated: 2026-04-23T11:31:31.369289+00:00
- Top-K: 5

## Blocking KPI

| Metric | Value |
|---|---|
| domain_hit_rate | 1.0 |
| file_hit_rate | 1.0 |
| cross_domain_leakage | 0.0 |

## Monitoring KPI

| Metric | Value |
|---|---|
| domain_hit_rate | 1.0 |
| file_hit_rate | 1.0 |
| cross_domain_leakage | 0.0 |

## KPI by Bucket

| Bucket | domain_hit_rate | file_hit_rate | cross_domain_leakage |
|---|---:|---:|---:|
| counterfactual-helpful | 1.0 | 1.0 | 0.0 |
| future | 1.0 | 1.0 | 0.0 |
| historical-agent | 1.0 | 1.0 | 0.0 |
| historical-user | 1.0 | 1.0 | 0.0 |
