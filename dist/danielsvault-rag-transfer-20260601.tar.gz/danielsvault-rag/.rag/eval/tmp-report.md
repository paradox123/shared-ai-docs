# RAG Eval Report

- Generated: 2026-04-23T11:07:40.469083+00:00
- Top-K: 5

## Blocking KPI

| Metric | Value |
|---|---|
| domain_hit_rate | 0.8824 |
| file_hit_rate | 0.9412 |
| cross_domain_leakage | 0.4706 |

## Monitoring KPI

| Metric | Value |
|---|---|
| domain_hit_rate | 0.9167 |
| file_hit_rate | 1.0 |
| cross_domain_leakage | 0.8333 |

## KPI by Bucket

| Bucket | domain_hit_rate | file_hit_rate | cross_domain_leakage |
|---|---:|---:|---:|
| counterfactual-helpful | 1.0 | 1.0 | 0.5 |
| future | 0.875 | 1.0 | 1.0 |
| historical-agent | 1.0 | 1.0 | 0.2857 |
| historical-user | 0.8 | 0.9 | 0.6 |
