#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

python3 -m venv .venv
. .venv/bin/activate
python -m ensurepip --upgrade
python -m pip install --upgrade pip setuptools wheel
pip install -e .

cat <<EOF
Installed DanielsVault RAG runtime.

For this shell, run:
  export PATH="$ROOT_DIR/.venv/bin:\$PATH"
  export DANIELSVAULT_ROOT="/path/to/DanielsVault"
  cd "$ROOT_DIR"
  rag runtime health
  rag runtime smoke
EOF
